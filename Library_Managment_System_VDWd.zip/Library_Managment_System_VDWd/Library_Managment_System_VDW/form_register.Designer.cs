﻿
namespace Library_Managment_System_VDW
{
    partial class form_register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_register));
            this.panel_Registration = new System.Windows.Forms.Panel();
            this.button_close = new System.Windows.Forms.PictureBox();
            this.panel_licensenumber = new System.Windows.Forms.Panel();
            this.text_licenseidnumber = new System.Windows.Forms.TextBox();
            this.button_register = new System.Windows.Forms.Button();
            this.panel_Fullname = new System.Windows.Forms.Panel();
            this.text_fullname = new System.Windows.Forms.TextBox();
            this.panel_password = new System.Windows.Forms.Panel();
            this.text_password = new System.Windows.Forms.TextBox();
            this.panel_username = new System.Windows.Forms.Panel();
            this.text_username = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label_liecenseidnumber = new System.Windows.Forms.Label();
            this.label_fullname = new System.Windows.Forms.Label();
            this.label_password = new System.Windows.Forms.Label();
            this.label_username = new System.Windows.Forms.Label();
            this.label_singup = new System.Windows.Forms.Label();
            this.panel_logo = new System.Windows.Forms.Panel();
            this.label_sublogo = new System.Windows.Forms.Label();
            this.label_logo = new System.Windows.Forms.Label();
            this.picture_logo = new System.Windows.Forms.PictureBox();
            this.pictureBox_go_backto_login = new System.Windows.Forms.PictureBox();
            this.panel_Registration.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).BeginInit();
            this.panel_licensenumber.SuspendLayout();
            this.panel_Fullname.SuspendLayout();
            this.panel_password.SuspendLayout();
            this.panel_username.SuspendLayout();
            this.panel_logo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_go_backto_login)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Registration
            // 
            this.panel_Registration.Controls.Add(this.pictureBox_go_backto_login);
            this.panel_Registration.Controls.Add(this.button_close);
            this.panel_Registration.Controls.Add(this.panel_licensenumber);
            this.panel_Registration.Controls.Add(this.button_register);
            this.panel_Registration.Controls.Add(this.panel_Fullname);
            this.panel_Registration.Controls.Add(this.panel_password);
            this.panel_Registration.Controls.Add(this.panel_username);
            this.panel_Registration.Controls.Add(this.label_liecenseidnumber);
            this.panel_Registration.Controls.Add(this.label_fullname);
            this.panel_Registration.Controls.Add(this.label_password);
            this.panel_Registration.Controls.Add(this.label_username);
            this.panel_Registration.Controls.Add(this.label_singup);
            this.panel_Registration.Location = new System.Drawing.Point(341, 3);
            this.panel_Registration.Name = "panel_Registration";
            this.panel_Registration.Size = new System.Drawing.Size(422, 440);
            this.panel_Registration.TabIndex = 4;
            // 
            // button_close
            // 
            this.button_close.Image = ((System.Drawing.Image)(resources.GetObject("button_close.Image")));
            this.button_close.Location = new System.Drawing.Point(389, 3);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(30, 30);
            this.button_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.button_close.TabIndex = 22;
            this.button_close.TabStop = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // panel_licensenumber
            // 
            this.panel_licensenumber.BackColor = System.Drawing.Color.Tan;
            this.panel_licensenumber.Controls.Add(this.text_licenseidnumber);
            this.panel_licensenumber.ForeColor = System.Drawing.Color.White;
            this.panel_licensenumber.Location = new System.Drawing.Point(66, 336);
            this.panel_licensenumber.Name = "panel_licensenumber";
            this.panel_licensenumber.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.panel_licensenumber.Size = new System.Drawing.Size(300, 30);
            this.panel_licensenumber.TabIndex = 17;
            // 
            // text_licenseidnumber
            // 
            this.text_licenseidnumber.BackColor = System.Drawing.Color.White;
            this.text_licenseidnumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_licenseidnumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.text_licenseidnumber.ForeColor = System.Drawing.Color.Black;
            this.text_licenseidnumber.Location = new System.Drawing.Point(0, 0);
            this.text_licenseidnumber.Multiline = true;
            this.text_licenseidnumber.Name = "text_licenseidnumber";
            this.text_licenseidnumber.Size = new System.Drawing.Size(300, 27);
            this.text_licenseidnumber.TabIndex = 0;
            // 
            // button_register
            // 
            this.button_register.BackColor = System.Drawing.Color.Tan;
            this.button_register.FlatAppearance.BorderSize = 0;
            this.button_register.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_register.ForeColor = System.Drawing.Color.White;
            this.button_register.Location = new System.Drawing.Point(124, 386);
            this.button_register.Margin = new System.Windows.Forms.Padding(0);
            this.button_register.Name = "button_register";
            this.button_register.Size = new System.Drawing.Size(176, 35);
            this.button_register.TabIndex = 21;
            this.button_register.Text = "Register";
            this.button_register.UseVisualStyleBackColor = false;
            this.button_register.Click += new System.EventHandler(this.button_register_Click);
            // 
            // panel_Fullname
            // 
            this.panel_Fullname.BackColor = System.Drawing.Color.Tan;
            this.panel_Fullname.Controls.Add(this.text_fullname);
            this.panel_Fullname.ForeColor = System.Drawing.Color.White;
            this.panel_Fullname.Location = new System.Drawing.Point(66, 167);
            this.panel_Fullname.Name = "panel_Fullname";
            this.panel_Fullname.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.panel_Fullname.Size = new System.Drawing.Size(300, 30);
            this.panel_Fullname.TabIndex = 18;
            // 
            // text_fullname
            // 
            this.text_fullname.BackColor = System.Drawing.Color.White;
            this.text_fullname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_fullname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.text_fullname.ForeColor = System.Drawing.Color.Black;
            this.text_fullname.Location = new System.Drawing.Point(0, 0);
            this.text_fullname.Multiline = true;
            this.text_fullname.Name = "text_fullname";
            this.text_fullname.Size = new System.Drawing.Size(300, 27);
            this.text_fullname.TabIndex = 0;
            // 
            // panel_password
            // 
            this.panel_password.BackColor = System.Drawing.Color.Tan;
            this.panel_password.Controls.Add(this.text_password);
            this.panel_password.ForeColor = System.Drawing.Color.White;
            this.panel_password.Location = new System.Drawing.Point(66, 254);
            this.panel_password.Name = "panel_password";
            this.panel_password.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.panel_password.Size = new System.Drawing.Size(300, 30);
            this.panel_password.TabIndex = 19;
            // 
            // text_password
            // 
            this.text_password.BackColor = System.Drawing.Color.White;
            this.text_password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_password.Dock = System.Windows.Forms.DockStyle.Fill;
            this.text_password.ForeColor = System.Drawing.Color.Black;
            this.text_password.Location = new System.Drawing.Point(0, 0);
            this.text_password.Multiline = true;
            this.text_password.Name = "text_password";
            this.text_password.Size = new System.Drawing.Size(300, 27);
            this.text_password.TabIndex = 0;
            // 
            // panel_username
            // 
            this.panel_username.BackColor = System.Drawing.Color.Tan;
            this.panel_username.Controls.Add(this.text_username);
            this.panel_username.Controls.Add(this.textBox2);
            this.panel_username.ForeColor = System.Drawing.Color.White;
            this.panel_username.Location = new System.Drawing.Point(66, 84);
            this.panel_username.Name = "panel_username";
            this.panel_username.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.panel_username.Size = new System.Drawing.Size(300, 30);
            this.panel_username.TabIndex = 20;
            // 
            // text_username
            // 
            this.text_username.BackColor = System.Drawing.Color.White;
            this.text_username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_username.Dock = System.Windows.Forms.DockStyle.Fill;
            this.text_username.ForeColor = System.Drawing.Color.Black;
            this.text_username.Location = new System.Drawing.Point(0, 0);
            this.text_username.Multiline = true;
            this.text_username.Name = "text_username";
            this.text_username.Size = new System.Drawing.Size(300, 27);
            this.text_username.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.ForeColor = System.Drawing.Color.Tan;
            this.textBox2.Location = new System.Drawing.Point(0, 0);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(300, 27);
            this.textBox2.TabIndex = 0;
            // 
            // label_liecenseidnumber
            // 
            this.label_liecenseidnumber.AutoSize = true;
            this.label_liecenseidnumber.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_liecenseidnumber.Location = new System.Drawing.Point(62, 312);
            this.label_liecenseidnumber.Name = "label_liecenseidnumber";
            this.label_liecenseidnumber.Size = new System.Drawing.Size(163, 19);
            this.label_liecenseidnumber.TabIndex = 12;
            this.label_liecenseidnumber.Text = "Liecense ID Number";
            // 
            // label_fullname
            // 
            this.label_fullname.AutoSize = true;
            this.label_fullname.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_fullname.Location = new System.Drawing.Point(62, 143);
            this.label_fullname.Name = "label_fullname";
            this.label_fullname.Size = new System.Drawing.Size(88, 19);
            this.label_fullname.TabIndex = 13;
            this.label_fullname.Text = "Full Name";
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_password.Location = new System.Drawing.Point(62, 230);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(80, 19);
            this.label_password.TabIndex = 14;
            this.label_password.Text = "Password";
            // 
            // label_username
            // 
            this.label_username.AutoSize = true;
            this.label_username.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_username.Location = new System.Drawing.Point(62, 60);
            this.label_username.Name = "label_username";
            this.label_username.Size = new System.Drawing.Size(93, 19);
            this.label_username.TabIndex = 15;
            this.label_username.Text = "User Name";
            // 
            // label_singup
            // 
            this.label_singup.AutoSize = true;
            this.label_singup.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_singup.Location = new System.Drawing.Point(38, 17);
            this.label_singup.Name = "label_singup";
            this.label_singup.Size = new System.Drawing.Size(345, 28);
            this.label_singup.TabIndex = 16;
            this.label_singup.Text = "Register As a New Employee";
            // 
            // panel_logo
            // 
            this.panel_logo.BackColor = System.Drawing.Color.Tan;
            this.panel_logo.Controls.Add(this.label_sublogo);
            this.panel_logo.Controls.Add(this.label_logo);
            this.panel_logo.Controls.Add(this.picture_logo);
            this.panel_logo.Location = new System.Drawing.Point(8, 3);
            this.panel_logo.Margin = new System.Windows.Forms.Padding(0);
            this.panel_logo.Name = "panel_logo";
            this.panel_logo.Size = new System.Drawing.Size(330, 440);
            this.panel_logo.TabIndex = 3;
            // 
            // label_sublogo
            // 
            this.label_sublogo.AutoSize = true;
            this.label_sublogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_sublogo.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sublogo.ForeColor = System.Drawing.Color.White;
            this.label_sublogo.Location = new System.Drawing.Point(50, 275);
            this.label_sublogo.Name = "label_sublogo";
            this.label_sublogo.Size = new System.Drawing.Size(194, 46);
            this.label_sublogo.TabIndex = 1;
            this.label_sublogo.Text = "Library \r\nManagment System";
            this.label_sublogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_logo
            // 
            this.label_logo.AutoSize = true;
            this.label_logo.ForeColor = System.Drawing.Color.White;
            this.label_logo.Location = new System.Drawing.Point(86, 209);
            this.label_logo.Name = "label_logo";
            this.label_logo.Size = new System.Drawing.Size(116, 21);
            this.label_logo.TabIndex = 1;
            this.label_logo.Text = "Insight Library";
            // 
            // picture_logo
            // 
            this.picture_logo.Image = ((System.Drawing.Image)(resources.GetObject("picture_logo.Image")));
            this.picture_logo.Location = new System.Drawing.Point(90, 87);
            this.picture_logo.Margin = new System.Windows.Forms.Padding(0);
            this.picture_logo.Name = "picture_logo";
            this.picture_logo.Size = new System.Drawing.Size(100, 110);
            this.picture_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture_logo.TabIndex = 0;
            this.picture_logo.TabStop = false;
            // 
            // pictureBox_go_backto_login
            // 
            this.pictureBox_go_backto_login.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_go_backto_login.Image")));
            this.pictureBox_go_backto_login.Location = new System.Drawing.Point(388, 39);
            this.pictureBox_go_backto_login.Name = "pictureBox_go_backto_login";
            this.pictureBox_go_backto_login.Size = new System.Drawing.Size(31, 21);
            this.pictureBox_go_backto_login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_go_backto_login.TabIndex = 23;
            this.pictureBox_go_backto_login.TabStop = false;
            this.pictureBox_go_backto_login.Click += new System.EventHandler(this.pictureBox_go_backto_login_Click);
            // 
            // form_register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(770, 447);
            this.Controls.Add(this.panel_Registration);
            this.Controls.Add(this.panel_logo);
            this.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.ForeColor = System.Drawing.Color.Tan;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "form_register";
            this.Text = "Form1";
            this.panel_Registration.ResumeLayout(false);
            this.panel_Registration.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).EndInit();
            this.panel_licensenumber.ResumeLayout(false);
            this.panel_licensenumber.PerformLayout();
            this.panel_Fullname.ResumeLayout(false);
            this.panel_Fullname.PerformLayout();
            this.panel_password.ResumeLayout(false);
            this.panel_password.PerformLayout();
            this.panel_username.ResumeLayout(false);
            this.panel_username.PerformLayout();
            this.panel_logo.ResumeLayout(false);
            this.panel_logo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_go_backto_login)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Registration;
        private System.Windows.Forms.PictureBox button_close;
        public System.Windows.Forms.Panel panel_licensenumber;
        private System.Windows.Forms.TextBox text_licenseidnumber;
        private System.Windows.Forms.Button button_register;
        public System.Windows.Forms.Panel panel_Fullname;
        private System.Windows.Forms.TextBox text_fullname;
        public System.Windows.Forms.Panel panel_password;
        private System.Windows.Forms.TextBox text_password;
        public System.Windows.Forms.Panel panel_username;
        private System.Windows.Forms.TextBox text_username;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label_liecenseidnumber;
        private System.Windows.Forms.Label label_fullname;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.Label label_username;
        private System.Windows.Forms.Label label_singup;
        private System.Windows.Forms.Panel panel_logo;
        private System.Windows.Forms.Label label_sublogo;
        private System.Windows.Forms.Label label_logo;
        private System.Windows.Forms.PictureBox picture_logo;
        private System.Windows.Forms.PictureBox pictureBox_go_backto_login;
    }
}