﻿
namespace Library_Managment_System_VDW
{
    partial class form_work_interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_work_interface));
            this.panel_book = new System.Windows.Forms.Panel();
            this.button_Search_Bookname_PanelBook = new System.Windows.Forms.Button();
            this.textBox_Search_Bookname_PanelBook = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button_Search_Book_PanelBook = new System.Windows.Forms.Button();
            this.textBox_Search_Book_PanelBook = new System.Windows.Forms.TextBox();
            this.button_close = new System.Windows.Forms.PictureBox();
            this.button_add_book = new System.Windows.Forms.Button();
            this.button_clear_book = new System.Windows.Forms.Button();
            this.button_delete_book = new System.Windows.Forms.Button();
            this.button_update_book = new System.Windows.Forms.Button();
            this.comboBox_book_gener = new System.Windows.Forms.ComboBox();
            this.comboBox_availability = new System.Windows.Forms.ComboBox();
            this.comboBox_book_language = new System.Windows.Forms.ComboBox();
            this.comboBox_book_shell = new System.Windows.Forms.ComboBox();
            this.label_tytel = new System.Windows.Forms.Label();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.dataGridView_books = new System.Windows.Forms.DataGridView();
            this.text_author = new System.Windows.Forms.TextBox();
            this.text_book_ref = new System.Windows.Forms.TextBox();
            this.text_bookname = new System.Windows.Forms.TextBox();
            this.label_book_gener = new System.Windows.Forms.Label();
            this.label_language = new System.Windows.Forms.Label();
            this.label_autor = new System.Windows.Forms.Label();
            this.label_availability = new System.Windows.Forms.Label();
            this.label_bookname = new System.Windows.Forms.Label();
            this.label_bookid_number = new System.Windows.Forms.Label();
            this.label_book_shell = new System.Windows.Forms.Label();
            this.panel_client = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.button_Search_clientname_panelclient = new System.Windows.Forms.Button();
            this.textBox_Search_clientname_panelclient = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_Search_client_panelclient = new System.Windows.Forms.Button();
            this.textBox_Search_client_panelclient = new System.Windows.Forms.TextBox();
            this.dataGridView_client = new System.Windows.Forms.DataGridView();
            this.text_email_address = new System.Windows.Forms.TextBox();
            this.text_phone_number = new System.Windows.Forms.TextBox();
            this.text_fullname_client = new System.Windows.Forms.TextBox();
            this.text_client_ref = new System.Windows.Forms.TextBox();
            this.label_email_address = new System.Windows.Forms.Label();
            this.label_phone_number = new System.Windows.Forms.Label();
            this.label_fullname_client = new System.Windows.Forms.Label();
            this.label_clientref = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_add_client = new System.Windows.Forms.Button();
            this.button_clear_client = new System.Windows.Forms.Button();
            this.button_delete_client = new System.Windows.Forms.Button();
            this.button_update_client = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.vScrollBar4 = new System.Windows.Forms.VScrollBar();
            this.panel_borrow_book = new System.Windows.Forms.Panel();
            this.button_S_B_S = new System.Windows.Forms.Button();
            this.textBox_S_B_S = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button_S_B = new System.Windows.Forms.Button();
            this.textBox_S_B = new System.Windows.Forms.TextBox();
            this.button_searchbar_borrow = new System.Windows.Forms.Button();
            this.textBox_searchbar_borrow = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker_due_date = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_borrowing_date = new System.Windows.Forms.DateTimePicker();
            this.comboBox_bookref = new System.Windows.Forms.ComboBox();
            this.bookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseDataSet = new Library_Managment_System_VDW.DatabaseDataSet();
            this.comboBox_clientref = new System.Windows.Forms.ComboBox();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseDataSet1 = new Library_Managment_System_VDW.DatabaseDataSet1();
            this.comboBox_username = new System.Windows.Forms.ComboBox();
            this.registerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseDataSet2 = new Library_Managment_System_VDW.DatabaseDataSet2();
            this.label_stuff_user_name = new System.Windows.Forms.Label();
            this.label_borrowing_date = new System.Windows.Forms.Label();
            this.label_due_date = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_add_borrowing = new System.Windows.Forms.Button();
            this.button_update_order = new System.Windows.Forms.Button();
            this.button_clear_order = new System.Windows.Forms.Button();
            this.button_delete_order = new System.Windows.Forms.Button();
            this.button_return_book = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lable_title_borrow = new System.Windows.Forms.Label();
            this.vScrollBar2 = new System.Windows.Forms.VScrollBar();
            this.dataGridView_borrow_book = new System.Windows.Forms.DataGridView();
            this.panel_control = new System.Windows.Forms.Panel();
            this.button_borrow_book = new System.Windows.Forms.Button();
            this.button_clientshandling = new System.Windows.Forms.Button();
            this.button_books = new System.Windows.Forms.Button();
            this.link_logout = new System.Windows.Forms.LinkLabel();
            this.label_sublogo = new System.Windows.Forms.Label();
            this.label_logo = new System.Windows.Forms.Label();
            this.picture_logo = new System.Windows.Forms.PictureBox();
            this.bookTableAdapter = new Library_Managment_System_VDW.DatabaseDataSetTableAdapters.BookTableAdapter();
            this.clientTableAdapter = new Library_Managment_System_VDW.DatabaseDataSet1TableAdapters.ClientTableAdapter();
            this.registerTableAdapter = new Library_Managment_System_VDW.DatabaseDataSet2TableAdapters.RegisterTableAdapter();
            this.panel_book.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_books)).BeginInit();
            this.panel_client.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_client)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_borrow_book.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.registerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_borrow_book)).BeginInit();
            this.panel_control.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_book
            // 
            this.panel_book.Controls.Add(this.button_Search_Bookname_PanelBook);
            this.panel_book.Controls.Add(this.textBox_Search_Bookname_PanelBook);
            this.panel_book.Controls.Add(this.label8);
            this.panel_book.Controls.Add(this.label7);
            this.panel_book.Controls.Add(this.button_Search_Book_PanelBook);
            this.panel_book.Controls.Add(this.textBox_Search_Book_PanelBook);
            this.panel_book.Controls.Add(this.button_close);
            this.panel_book.Controls.Add(this.button_add_book);
            this.panel_book.Controls.Add(this.button_clear_book);
            this.panel_book.Controls.Add(this.button_delete_book);
            this.panel_book.Controls.Add(this.button_update_book);
            this.panel_book.Controls.Add(this.comboBox_book_gener);
            this.panel_book.Controls.Add(this.comboBox_availability);
            this.panel_book.Controls.Add(this.comboBox_book_language);
            this.panel_book.Controls.Add(this.comboBox_book_shell);
            this.panel_book.Controls.Add(this.label_tytel);
            this.panel_book.Controls.Add(this.vScrollBar1);
            this.panel_book.Controls.Add(this.dataGridView_books);
            this.panel_book.Controls.Add(this.text_author);
            this.panel_book.Controls.Add(this.text_book_ref);
            this.panel_book.Controls.Add(this.text_bookname);
            this.panel_book.Controls.Add(this.label_book_gener);
            this.panel_book.Controls.Add(this.label_language);
            this.panel_book.Controls.Add(this.label_autor);
            this.panel_book.Controls.Add(this.label_availability);
            this.panel_book.Controls.Add(this.label_bookname);
            this.panel_book.Controls.Add(this.label_bookid_number);
            this.panel_book.Controls.Add(this.label_book_shell);
            this.panel_book.Location = new System.Drawing.Point(307, 12);
            this.panel_book.Name = "panel_book";
            this.panel_book.Size = new System.Drawing.Size(1161, 497);
            this.panel_book.TabIndex = 12;
            this.panel_book.Visible = false;
            // 
            // button_Search_Bookname_PanelBook
            // 
            this.button_Search_Bookname_PanelBook.Location = new System.Drawing.Point(1031, 97);
            this.button_Search_Bookname_PanelBook.Name = "button_Search_Bookname_PanelBook";
            this.button_Search_Bookname_PanelBook.Size = new System.Drawing.Size(73, 26);
            this.button_Search_Bookname_PanelBook.TabIndex = 100;
            this.button_Search_Bookname_PanelBook.Text = "Search";
            this.button_Search_Bookname_PanelBook.UseVisualStyleBackColor = true;
            this.button_Search_Bookname_PanelBook.Click += new System.EventHandler(this.button_Search_Bookname_PanelBook_Click);
            // 
            // textBox_Search_Bookname_PanelBook
            // 
            this.textBox_Search_Bookname_PanelBook.Location = new System.Drawing.Point(891, 97);
            this.textBox_Search_Bookname_PanelBook.Name = "textBox_Search_Bookname_PanelBook";
            this.textBox_Search_Bookname_PanelBook.Size = new System.Drawing.Size(134, 27);
            this.textBox_Search_Bookname_PanelBook.TabIndex = 99;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(898, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(188, 19);
            this.label8.TabIndex = 98;
            this.label8.Text = "Search By Book Name :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(449, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(162, 19);
            this.label7.TabIndex = 97;
            this.label7.Text = "Search By Book Ref :";
            // 
            // button_Search_Book_PanelBook
            // 
            this.button_Search_Book_PanelBook.Location = new System.Drawing.Point(572, 97);
            this.button_Search_Book_PanelBook.Name = "button_Search_Book_PanelBook";
            this.button_Search_Book_PanelBook.Size = new System.Drawing.Size(73, 26);
            this.button_Search_Book_PanelBook.TabIndex = 74;
            this.button_Search_Book_PanelBook.Text = "Search";
            this.button_Search_Book_PanelBook.UseVisualStyleBackColor = true;
            this.button_Search_Book_PanelBook.Click += new System.EventHandler(this.button_Search_Book_PanelBook_Click);
            // 
            // textBox_Search_Book_PanelBook
            // 
            this.textBox_Search_Book_PanelBook.Location = new System.Drawing.Point(432, 97);
            this.textBox_Search_Book_PanelBook.Name = "textBox_Search_Book_PanelBook";
            this.textBox_Search_Book_PanelBook.Size = new System.Drawing.Size(134, 27);
            this.textBox_Search_Book_PanelBook.TabIndex = 73;
            // 
            // button_close
            // 
            this.button_close.Image = ((System.Drawing.Image)(resources.GetObject("button_close.Image")));
            this.button_close.Location = new System.Drawing.Point(1131, 0);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(30, 30);
            this.button_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.button_close.TabIndex = 72;
            this.button_close.TabStop = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // button_add_book
            // 
            this.button_add_book.BackColor = System.Drawing.Color.Tan;
            this.button_add_book.FlatAppearance.BorderSize = 0;
            this.button_add_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add_book.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_add_book.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_add_book.Location = new System.Drawing.Point(362, 444);
            this.button_add_book.Margin = new System.Windows.Forms.Padding(0);
            this.button_add_book.Name = "button_add_book";
            this.button_add_book.Size = new System.Drawing.Size(89, 35);
            this.button_add_book.TabIndex = 71;
            this.button_add_book.Text = "Add";
            this.button_add_book.UseVisualStyleBackColor = false;
            this.button_add_book.Click += new System.EventHandler(this.button_add_book_Click);
            // 
            // button_clear_book
            // 
            this.button_clear_book.BackColor = System.Drawing.Color.Tan;
            this.button_clear_book.FlatAppearance.BorderSize = 0;
            this.button_clear_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_clear_book.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear_book.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_clear_book.Location = new System.Drawing.Point(687, 443);
            this.button_clear_book.Margin = new System.Windows.Forms.Padding(0);
            this.button_clear_book.Name = "button_clear_book";
            this.button_clear_book.Size = new System.Drawing.Size(89, 35);
            this.button_clear_book.TabIndex = 69;
            this.button_clear_book.Text = "Clear";
            this.button_clear_book.UseVisualStyleBackColor = false;
            this.button_clear_book.Click += new System.EventHandler(this.button_clear_book_Click);
            // 
            // button_delete_book
            // 
            this.button_delete_book.BackColor = System.Drawing.Color.Tan;
            this.button_delete_book.FlatAppearance.BorderSize = 0;
            this.button_delete_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_delete_book.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete_book.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_delete_book.Location = new System.Drawing.Point(577, 443);
            this.button_delete_book.Margin = new System.Windows.Forms.Padding(0);
            this.button_delete_book.Name = "button_delete_book";
            this.button_delete_book.Size = new System.Drawing.Size(89, 35);
            this.button_delete_book.TabIndex = 70;
            this.button_delete_book.Text = "Delete";
            this.button_delete_book.UseVisualStyleBackColor = false;
            this.button_delete_book.Click += new System.EventHandler(this.button_delete_book_Click);
            // 
            // button_update_book
            // 
            this.button_update_book.BackColor = System.Drawing.Color.Tan;
            this.button_update_book.FlatAppearance.BorderSize = 0;
            this.button_update_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update_book.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update_book.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_update_book.Location = new System.Drawing.Point(466, 443);
            this.button_update_book.Margin = new System.Windows.Forms.Padding(0);
            this.button_update_book.Name = "button_update_book";
            this.button_update_book.Size = new System.Drawing.Size(89, 35);
            this.button_update_book.TabIndex = 68;
            this.button_update_book.Text = "Update";
            this.button_update_book.UseVisualStyleBackColor = false;
            this.button_update_book.Click += new System.EventHandler(this.button_update_book_Click);
            // 
            // comboBox_book_gener
            // 
            this.comboBox_book_gener.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_book_gener.FormattingEnabled = true;
            this.comboBox_book_gener.Items.AddRange(new object[] {
            "Fiction",
            "Non-fiction",
            "Romance",
            "Mystery",
            "Thriller",
            "Horror",
            "Science fiction",
            "Fantasy",
            "Historical fiction",
            "Biography",
            "Autobiography",
            "Memoir",
            "Self-help",
            "Business",
            "Travel",
            "Children\'s",
            "Young adult",
            "Comedy",
            "Drama",
            "Poetry"});
            this.comboBox_book_gener.Location = new System.Drawing.Point(189, 177);
            this.comboBox_book_gener.Name = "comboBox_book_gener";
            this.comboBox_book_gener.Size = new System.Drawing.Size(173, 29);
            this.comboBox_book_gener.TabIndex = 50;
            // 
            // comboBox_availability
            // 
            this.comboBox_availability.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_availability.FormattingEnabled = true;
            this.comboBox_availability.Items.AddRange(new object[] {
            "Available",
            "Still not available"});
            this.comboBox_availability.Location = new System.Drawing.Point(188, 402);
            this.comboBox_availability.Name = "comboBox_availability";
            this.comboBox_availability.Size = new System.Drawing.Size(173, 29);
            this.comboBox_availability.TabIndex = 50;
            // 
            // comboBox_book_language
            // 
            this.comboBox_book_language.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_book_language.FormattingEnabled = true;
            this.comboBox_book_language.Items.AddRange(new object[] {
            "English",
            "Spanish",
            "French",
            "German",
            "Mandarin Chinese",
            "Japanese",
            "Arabic",
            "Portuguese",
            "Russian",
            "Italian",
            "Dutch",
            "Swedish",
            "Korean",
            "Greek",
            "Hindi"});
            this.comboBox_book_language.Location = new System.Drawing.Point(189, 234);
            this.comboBox_book_language.Name = "comboBox_book_language";
            this.comboBox_book_language.Size = new System.Drawing.Size(173, 29);
            this.comboBox_book_language.TabIndex = 50;
            // 
            // comboBox_book_shell
            // 
            this.comboBox_book_shell.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_book_shell.FormattingEnabled = true;
            this.comboBox_book_shell.Items.AddRange(new object[] {
            "Shell 1, Zone1",
            "Shell 2, Zone1",
            "Shell 3, Zone1",
            "Shell 4, Zone1",
            "Shell 5, Zone1",
            "Shell 6, Zone1",
            "Shell 7, Zone1",
            "Shell 8, Zone1",
            "Shell 9, Zone1",
            "Shell 10, Zone1",
            "Shell 1, Zone2",
            "Shell 2, Zone2",
            "Shell 3, Zone2",
            "Shell 4, Zone2",
            "Shell 5, Zone2",
            "Shell 6, Zone2",
            "Shell 7, Zone2",
            "Shell 8, Zone2",
            "Shell 9, Zone2",
            "Shell 10, Zone2"});
            this.comboBox_book_shell.Location = new System.Drawing.Point(188, 349);
            this.comboBox_book_shell.Name = "comboBox_book_shell";
            this.comboBox_book_shell.Size = new System.Drawing.Size(173, 29);
            this.comboBox_book_shell.TabIndex = 50;
            // 
            // label_tytel
            // 
            this.label_tytel.AutoSize = true;
            this.label_tytel.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_tytel.ForeColor = System.Drawing.Color.DimGray;
            this.label_tytel.Location = new System.Drawing.Point(571, 11);
            this.label_tytel.Name = "label_tytel";
            this.label_tytel.Size = new System.Drawing.Size(335, 32);
            this.label_tytel.TabIndex = 4;
            this.label_tytel.Text = "Insight Books Mangment";
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(1125, 129);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(17, 292);
            this.vScrollBar1.TabIndex = 3;
            // 
            // dataGridView_books
            // 
            this.dataGridView_books.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_books.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dataGridView_books.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_books.Location = new System.Drawing.Point(408, 129);
            this.dataGridView_books.Name = "dataGridView_books";
            this.dataGridView_books.RowHeadersWidth = 62;
            this.dataGridView_books.Size = new System.Drawing.Size(714, 292);
            this.dataGridView_books.TabIndex = 2;
            this.dataGridView_books.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_books_CellContentClick);
            // 
            // text_author
            // 
            this.text_author.Location = new System.Drawing.Point(188, 292);
            this.text_author.Name = "text_author";
            this.text_author.Size = new System.Drawing.Size(173, 27);
            this.text_author.TabIndex = 1;
            // 
            // text_book_ref
            // 
            this.text_book_ref.Location = new System.Drawing.Point(217, 53);
            this.text_book_ref.Name = "text_book_ref";
            this.text_book_ref.Size = new System.Drawing.Size(173, 27);
            this.text_book_ref.TabIndex = 1;
            // 
            // text_bookname
            // 
            this.text_bookname.Location = new System.Drawing.Point(189, 115);
            this.text_bookname.Name = "text_bookname";
            this.text_bookname.Size = new System.Drawing.Size(173, 27);
            this.text_bookname.TabIndex = 1;
            // 
            // label_book_gener
            // 
            this.label_book_gener.AutoSize = true;
            this.label_book_gener.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_book_gener.ForeColor = System.Drawing.Color.DimGray;
            this.label_book_gener.Location = new System.Drawing.Point(30, 181);
            this.label_book_gener.Name = "label_book_gener";
            this.label_book_gener.Size = new System.Drawing.Size(65, 19);
            this.label_book_gener.TabIndex = 0;
            this.label_book_gener.Text = "Gener :";
            // 
            // label_language
            // 
            this.label_language.AutoSize = true;
            this.label_language.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_language.ForeColor = System.Drawing.Color.DimGray;
            this.label_language.Location = new System.Drawing.Point(29, 238);
            this.label_language.Name = "label_language";
            this.label_language.Size = new System.Drawing.Size(98, 19);
            this.label_language.TabIndex = 0;
            this.label_language.Text = "Language :";
            // 
            // label_autor
            // 
            this.label_autor.AutoSize = true;
            this.label_autor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_autor.ForeColor = System.Drawing.Color.DimGray;
            this.label_autor.Location = new System.Drawing.Point(29, 296);
            this.label_autor.Name = "label_autor";
            this.label_autor.Size = new System.Drawing.Size(68, 19);
            this.label_autor.TabIndex = 0;
            this.label_autor.Text = "Author :";
            // 
            // label_availability
            // 
            this.label_availability.AutoSize = true;
            this.label_availability.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_availability.ForeColor = System.Drawing.Color.DimGray;
            this.label_availability.Location = new System.Drawing.Point(29, 402);
            this.label_availability.Name = "label_availability";
            this.label_availability.Size = new System.Drawing.Size(104, 19);
            this.label_availability.TabIndex = 0;
            this.label_availability.Text = "Avaialbility :";
            // 
            // label_bookname
            // 
            this.label_bookname.AutoSize = true;
            this.label_bookname.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bookname.ForeColor = System.Drawing.Color.DimGray;
            this.label_bookname.Location = new System.Drawing.Point(28, 119);
            this.label_bookname.Name = "label_bookname";
            this.label_bookname.Size = new System.Drawing.Size(108, 19);
            this.label_bookname.TabIndex = 0;
            this.label_bookname.Text = "Book Name :";
            // 
            // label_bookid_number
            // 
            this.label_bookid_number.AutoSize = true;
            this.label_bookid_number.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bookid_number.ForeColor = System.Drawing.Color.DimGray;
            this.label_bookid_number.Location = new System.Drawing.Point(3, 57);
            this.label_bookid_number.Name = "label_bookid_number";
            this.label_bookid_number.Size = new System.Drawing.Size(208, 19);
            this.label_bookid_number.TabIndex = 0;
            this.label_bookid_number.Text = "Book Reference (unique) :";
            // 
            // label_book_shell
            // 
            this.label_book_shell.AutoSize = true;
            this.label_book_shell.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_book_shell.ForeColor = System.Drawing.Color.DimGray;
            this.label_book_shell.Location = new System.Drawing.Point(28, 351);
            this.label_book_shell.Name = "label_book_shell";
            this.label_book_shell.Size = new System.Drawing.Size(95, 19);
            this.label_book_shell.TabIndex = 0;
            this.label_book_shell.Text = "Book Shell :";
            // 
            // panel_client
            // 
            this.panel_client.Controls.Add(this.label9);
            this.panel_client.Controls.Add(this.button_Search_clientname_panelclient);
            this.panel_client.Controls.Add(this.textBox_Search_clientname_panelclient);
            this.panel_client.Controls.Add(this.label2);
            this.panel_client.Controls.Add(this.button_Search_client_panelclient);
            this.panel_client.Controls.Add(this.textBox_Search_client_panelclient);
            this.panel_client.Controls.Add(this.dataGridView_client);
            this.panel_client.Controls.Add(this.text_email_address);
            this.panel_client.Controls.Add(this.text_phone_number);
            this.panel_client.Controls.Add(this.text_fullname_client);
            this.panel_client.Controls.Add(this.text_client_ref);
            this.panel_client.Controls.Add(this.label_email_address);
            this.panel_client.Controls.Add(this.label_phone_number);
            this.panel_client.Controls.Add(this.label_fullname_client);
            this.panel_client.Controls.Add(this.label_clientref);
            this.panel_client.Controls.Add(this.pictureBox1);
            this.panel_client.Controls.Add(this.button_add_client);
            this.panel_client.Controls.Add(this.button_clear_client);
            this.panel_client.Controls.Add(this.button_delete_client);
            this.panel_client.Controls.Add(this.button_update_client);
            this.panel_client.Controls.Add(this.label3);
            this.panel_client.Controls.Add(this.vScrollBar4);
            this.panel_client.Location = new System.Drawing.Point(307, 12);
            this.panel_client.Name = "panel_client";
            this.panel_client.Size = new System.Drawing.Size(1161, 570);
            this.panel_client.TabIndex = 18;
            this.panel_client.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(879, 66);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(194, 19);
            this.label9.TabIndex = 100;
            this.label9.Text = "Search By Client Name :";
            // 
            // button_Search_clientname_panelclient
            // 
            this.button_Search_clientname_panelclient.Location = new System.Drawing.Point(1012, 93);
            this.button_Search_clientname_panelclient.Name = "button_Search_clientname_panelclient";
            this.button_Search_clientname_panelclient.Size = new System.Drawing.Size(73, 27);
            this.button_Search_clientname_panelclient.TabIndex = 99;
            this.button_Search_clientname_panelclient.Text = "Search";
            this.button_Search_clientname_panelclient.UseVisualStyleBackColor = true;
            this.button_Search_clientname_panelclient.Click += new System.EventHandler(this.button_Search_clientname_panelclient_Click);
            // 
            // textBox_Search_clientname_panelclient
            // 
            this.textBox_Search_clientname_panelclient.Location = new System.Drawing.Point(872, 93);
            this.textBox_Search_clientname_panelclient.Name = "textBox_Search_clientname_panelclient";
            this.textBox_Search_clientname_panelclient.Size = new System.Drawing.Size(134, 27);
            this.textBox_Search_clientname_panelclient.TabIndex = 98;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(443, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 19);
            this.label2.TabIndex = 97;
            this.label2.Text = "Search By Client Ref :";
            // 
            // button_Search_client_panelclient
            // 
            this.button_Search_client_panelclient.Location = new System.Drawing.Point(572, 94);
            this.button_Search_client_panelclient.Name = "button_Search_client_panelclient";
            this.button_Search_client_panelclient.Size = new System.Drawing.Size(73, 27);
            this.button_Search_client_panelclient.TabIndex = 84;
            this.button_Search_client_panelclient.Text = "Search";
            this.button_Search_client_panelclient.UseVisualStyleBackColor = true;
            this.button_Search_client_panelclient.Click += new System.EventHandler(this.button_Search_client_panelclient_Click);
            // 
            // textBox_Search_client_panelclient
            // 
            this.textBox_Search_client_panelclient.Location = new System.Drawing.Point(432, 94);
            this.textBox_Search_client_panelclient.Name = "textBox_Search_client_panelclient";
            this.textBox_Search_client_panelclient.Size = new System.Drawing.Size(134, 27);
            this.textBox_Search_client_panelclient.TabIndex = 83;
            // 
            // dataGridView_client
            // 
            this.dataGridView_client.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_client.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dataGridView_client.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_client.Location = new System.Drawing.Point(395, 127);
            this.dataGridView_client.Name = "dataGridView_client";
            this.dataGridView_client.RowHeadersWidth = 62;
            this.dataGridView_client.Size = new System.Drawing.Size(714, 292);
            this.dataGridView_client.TabIndex = 82;
            this.dataGridView_client.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_client_CellContentClick);
            // 
            // text_email_address
            // 
            this.text_email_address.Location = new System.Drawing.Point(189, 344);
            this.text_email_address.Name = "text_email_address";
            this.text_email_address.Size = new System.Drawing.Size(173, 27);
            this.text_email_address.TabIndex = 81;
            // 
            // text_phone_number
            // 
            this.text_phone_number.Location = new System.Drawing.Point(189, 265);
            this.text_phone_number.Name = "text_phone_number";
            this.text_phone_number.Size = new System.Drawing.Size(173, 27);
            this.text_phone_number.TabIndex = 81;
            // 
            // text_fullname_client
            // 
            this.text_fullname_client.Location = new System.Drawing.Point(189, 179);
            this.text_fullname_client.Name = "text_fullname_client";
            this.text_fullname_client.Size = new System.Drawing.Size(173, 27);
            this.text_fullname_client.TabIndex = 80;
            // 
            // text_client_ref
            // 
            this.text_client_ref.Location = new System.Drawing.Point(217, 93);
            this.text_client_ref.Name = "text_client_ref";
            this.text_client_ref.Size = new System.Drawing.Size(174, 27);
            this.text_client_ref.TabIndex = 79;
            // 
            // label_email_address
            // 
            this.label_email_address.AutoSize = true;
            this.label_email_address.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_email_address.ForeColor = System.Drawing.Color.DimGray;
            this.label_email_address.Location = new System.Drawing.Point(38, 348);
            this.label_email_address.Name = "label_email_address";
            this.label_email_address.Size = new System.Drawing.Size(125, 19);
            this.label_email_address.TabIndex = 76;
            this.label_email_address.Text = "Email Address :";
            // 
            // label_phone_number
            // 
            this.label_phone_number.AutoSize = true;
            this.label_phone_number.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_phone_number.ForeColor = System.Drawing.Color.DimGray;
            this.label_phone_number.Location = new System.Drawing.Point(38, 269);
            this.label_phone_number.Name = "label_phone_number";
            this.label_phone_number.Size = new System.Drawing.Size(134, 19);
            this.label_phone_number.TabIndex = 76;
            this.label_phone_number.Text = "Phone Number :";
            // 
            // label_fullname_client
            // 
            this.label_fullname_client.AutoSize = true;
            this.label_fullname_client.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_fullname_client.ForeColor = System.Drawing.Color.DimGray;
            this.label_fullname_client.Location = new System.Drawing.Point(38, 183);
            this.label_fullname_client.Name = "label_fullname_client";
            this.label_fullname_client.Size = new System.Drawing.Size(96, 19);
            this.label_fullname_client.TabIndex = 74;
            this.label_fullname_client.Text = "Full Name :";
            // 
            // label_clientref
            // 
            this.label_clientref.AutoSize = true;
            this.label_clientref.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_clientref.ForeColor = System.Drawing.Color.DimGray;
            this.label_clientref.Location = new System.Drawing.Point(1, 97);
            this.label_clientref.Name = "label_clientref";
            this.label_clientref.Size = new System.Drawing.Size(210, 19);
            this.label_clientref.TabIndex = 78;
            this.label_clientref.Text = "Client Reference (unique):";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1131, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 72;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button_add_client
            // 
            this.button_add_client.BackColor = System.Drawing.Color.Tan;
            this.button_add_client.FlatAppearance.BorderSize = 0;
            this.button_add_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add_client.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_add_client.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_add_client.Location = new System.Drawing.Point(566, 444);
            this.button_add_client.Margin = new System.Windows.Forms.Padding(0);
            this.button_add_client.Name = "button_add_client";
            this.button_add_client.Size = new System.Drawing.Size(89, 35);
            this.button_add_client.TabIndex = 71;
            this.button_add_client.Text = "Add";
            this.button_add_client.UseVisualStyleBackColor = false;
            this.button_add_client.Click += new System.EventHandler(this.button_add_client_Click);
            // 
            // button_clear_client
            // 
            this.button_clear_client.BackColor = System.Drawing.Color.Tan;
            this.button_clear_client.FlatAppearance.BorderSize = 0;
            this.button_clear_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_clear_client.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear_client.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_clear_client.Location = new System.Drawing.Point(891, 443);
            this.button_clear_client.Margin = new System.Windows.Forms.Padding(0);
            this.button_clear_client.Name = "button_clear_client";
            this.button_clear_client.Size = new System.Drawing.Size(89, 35);
            this.button_clear_client.TabIndex = 69;
            this.button_clear_client.Text = "Clear";
            this.button_clear_client.UseVisualStyleBackColor = false;
            this.button_clear_client.Click += new System.EventHandler(this.button_clear_client_Click);
            // 
            // button_delete_client
            // 
            this.button_delete_client.BackColor = System.Drawing.Color.Tan;
            this.button_delete_client.FlatAppearance.BorderSize = 0;
            this.button_delete_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_delete_client.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete_client.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_delete_client.Location = new System.Drawing.Point(781, 443);
            this.button_delete_client.Margin = new System.Windows.Forms.Padding(0);
            this.button_delete_client.Name = "button_delete_client";
            this.button_delete_client.Size = new System.Drawing.Size(89, 35);
            this.button_delete_client.TabIndex = 70;
            this.button_delete_client.Text = "Delete";
            this.button_delete_client.UseVisualStyleBackColor = false;
            this.button_delete_client.Click += new System.EventHandler(this.button_delete_client_Click);
            // 
            // button_update_client
            // 
            this.button_update_client.BackColor = System.Drawing.Color.Tan;
            this.button_update_client.FlatAppearance.BorderSize = 0;
            this.button_update_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update_client.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update_client.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_update_client.Location = new System.Drawing.Point(670, 443);
            this.button_update_client.Margin = new System.Windows.Forms.Padding(0);
            this.button_update_client.Name = "button_update_client";
            this.button_update_client.Size = new System.Drawing.Size(89, 35);
            this.button_update_client.TabIndex = 68;
            this.button_update_client.Text = "Update";
            this.button_update_client.UseVisualStyleBackColor = false;
            this.button_update_client.Click += new System.EventHandler(this.button_update_client_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(596, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(317, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "Insight Clients Handling";
            // 
            // vScrollBar4
            // 
            this.vScrollBar4.Location = new System.Drawing.Point(1125, 119);
            this.vScrollBar4.Name = "vScrollBar4";
            this.vScrollBar4.Size = new System.Drawing.Size(17, 292);
            this.vScrollBar4.TabIndex = 3;
            // 
            // panel_borrow_book
            // 
            this.panel_borrow_book.Controls.Add(this.button_S_B_S);
            this.panel_borrow_book.Controls.Add(this.textBox_S_B_S);
            this.panel_borrow_book.Controls.Add(this.label10);
            this.panel_borrow_book.Controls.Add(this.label6);
            this.panel_borrow_book.Controls.Add(this.button_S_B);
            this.panel_borrow_book.Controls.Add(this.textBox_S_B);
            this.panel_borrow_book.Controls.Add(this.button_searchbar_borrow);
            this.panel_borrow_book.Controls.Add(this.textBox_searchbar_borrow);
            this.panel_borrow_book.Controls.Add(this.label5);
            this.panel_borrow_book.Controls.Add(this.label1);
            this.panel_borrow_book.Controls.Add(this.dateTimePicker_due_date);
            this.panel_borrow_book.Controls.Add(this.dateTimePicker_borrowing_date);
            this.panel_borrow_book.Controls.Add(this.comboBox_bookref);
            this.panel_borrow_book.Controls.Add(this.comboBox_clientref);
            this.panel_borrow_book.Controls.Add(this.comboBox_username);
            this.panel_borrow_book.Controls.Add(this.label_stuff_user_name);
            this.panel_borrow_book.Controls.Add(this.label_borrowing_date);
            this.panel_borrow_book.Controls.Add(this.label_due_date);
            this.panel_borrow_book.Controls.Add(this.pictureBox2);
            this.panel_borrow_book.Controls.Add(this.button_add_borrowing);
            this.panel_borrow_book.Controls.Add(this.button_update_order);
            this.panel_borrow_book.Controls.Add(this.button_clear_order);
            this.panel_borrow_book.Controls.Add(this.button_delete_order);
            this.panel_borrow_book.Controls.Add(this.button_return_book);
            this.panel_borrow_book.Controls.Add(this.label4);
            this.panel_borrow_book.Controls.Add(this.lable_title_borrow);
            this.panel_borrow_book.Controls.Add(this.vScrollBar2);
            this.panel_borrow_book.Controls.Add(this.dataGridView_borrow_book);
            this.panel_borrow_book.Location = new System.Drawing.Point(307, 12);
            this.panel_borrow_book.Name = "panel_borrow_book";
            this.panel_borrow_book.Size = new System.Drawing.Size(1161, 497);
            this.panel_borrow_book.TabIndex = 11;
            this.panel_borrow_book.Visible = false;
            // 
            // button_S_B_S
            // 
            this.button_S_B_S.Location = new System.Drawing.Point(1052, 82);
            this.button_S_B_S.Name = "button_S_B_S";
            this.button_S_B_S.Size = new System.Drawing.Size(72, 28);
            this.button_S_B_S.TabIndex = 98;
            this.button_S_B_S.Text = "Search";
            this.button_S_B_S.UseVisualStyleBackColor = true;
            this.button_S_B_S.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_S_B_S
            // 
            this.textBox_S_B_S.Location = new System.Drawing.Point(953, 83);
            this.textBox_S_B_S.Name = "textBox_S_B_S";
            this.textBox_S_B_S.Size = new System.Drawing.Size(93, 27);
            this.textBox_S_B_S.TabIndex = 97;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DimGray;
            this.label10.Location = new System.Drawing.Point(978, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(127, 19);
            this.label10.TabIndex = 96;
            this.label10.Text = "Search By Stuff :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(701, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(162, 19);
            this.label6.TabIndex = 96;
            this.label6.Text = "Search By Book Ref :";
            // 
            // button_S_B
            // 
            this.button_S_B.Location = new System.Drawing.Point(791, 81);
            this.button_S_B.Name = "button_S_B";
            this.button_S_B.Size = new System.Drawing.Size(72, 28);
            this.button_S_B.TabIndex = 95;
            this.button_S_B.Text = "Search";
            this.button_S_B.UseVisualStyleBackColor = true;
            this.button_S_B.Click += new System.EventHandler(this.button_S_B_Click);
            // 
            // textBox_S_B
            // 
            this.textBox_S_B.Location = new System.Drawing.Point(692, 83);
            this.textBox_S_B.Name = "textBox_S_B";
            this.textBox_S_B.Size = new System.Drawing.Size(93, 27);
            this.textBox_S_B.TabIndex = 94;
            // 
            // button_searchbar_borrow
            // 
            this.button_searchbar_borrow.Location = new System.Drawing.Point(507, 83);
            this.button_searchbar_borrow.Name = "button_searchbar_borrow";
            this.button_searchbar_borrow.Size = new System.Drawing.Size(72, 27);
            this.button_searchbar_borrow.TabIndex = 93;
            this.button_searchbar_borrow.Text = "Search";
            this.button_searchbar_borrow.UseVisualStyleBackColor = true;
            this.button_searchbar_borrow.Click += new System.EventHandler(this.button_searchbar_borrow_Click);
            // 
            // textBox_searchbar_borrow
            // 
            this.textBox_searchbar_borrow.Location = new System.Drawing.Point(408, 83);
            this.textBox_searchbar_borrow.Name = "textBox_searchbar_borrow";
            this.textBox_searchbar_borrow.Size = new System.Drawing.Size(93, 27);
            this.textBox_searchbar_borrow.TabIndex = 92;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(36, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 19);
            this.label5.TabIndex = 91;
            this.label5.Text = "Client Reference :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(38, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 19);
            this.label1.TabIndex = 89;
            this.label1.Text = "Book Reference :";
            // 
            // dateTimePicker_due_date
            // 
            this.dateTimePicker_due_date.Location = new System.Drawing.Point(187, 396);
            this.dateTimePicker_due_date.Name = "dateTimePicker_due_date";
            this.dateTimePicker_due_date.Size = new System.Drawing.Size(200, 27);
            this.dateTimePicker_due_date.TabIndex = 88;
            // 
            // dateTimePicker_borrowing_date
            // 
            this.dateTimePicker_borrowing_date.Location = new System.Drawing.Point(187, 324);
            this.dateTimePicker_borrowing_date.Name = "dateTimePicker_borrowing_date";
            this.dateTimePicker_borrowing_date.Size = new System.Drawing.Size(200, 27);
            this.dateTimePicker_borrowing_date.TabIndex = 88;
            // 
            // comboBox_bookref
            // 
            this.comboBox_bookref.DataSource = this.bookBindingSource;
            this.comboBox_bookref.DisplayMember = "Book_Ref";
            this.comboBox_bookref.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_bookref.FormattingEnabled = true;
            this.comboBox_bookref.Location = new System.Drawing.Point(186, 99);
            this.comboBox_bookref.Name = "comboBox_bookref";
            this.comboBox_bookref.Size = new System.Drawing.Size(200, 29);
            this.comboBox_bookref.TabIndex = 83;
            this.comboBox_bookref.ValueMember = "Book_Ref";
            this.comboBox_bookref.SelectedIndexChanged += new System.EventHandler(this.comboBox_bookref_SelectedIndexChanged);
            // 
            // bookBindingSource
            // 
            this.bookBindingSource.DataMember = "Book";
            this.bookBindingSource.DataSource = this.databaseDataSet;
            // 
            // databaseDataSet
            // 
            this.databaseDataSet.DataSetName = "DatabaseDataSet";
            this.databaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox_clientref
            // 
            this.comboBox_clientref.DataSource = this.clientBindingSource;
            this.comboBox_clientref.DisplayMember = "Client_Ref";
            this.comboBox_clientref.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_clientref.FormattingEnabled = true;
            this.comboBox_clientref.Location = new System.Drawing.Point(185, 176);
            this.comboBox_clientref.Name = "comboBox_clientref";
            this.comboBox_clientref.Size = new System.Drawing.Size(200, 29);
            this.comboBox_clientref.TabIndex = 83;
            this.comboBox_clientref.ValueMember = "Client_Ref";
            this.comboBox_clientref.SelectedIndexChanged += new System.EventHandler(this.comboBox_clientref_SelectedIndexChanged);
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.databaseDataSet1;
            // 
            // databaseDataSet1
            // 
            this.databaseDataSet1.DataSetName = "DatabaseDataSet1";
            this.databaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox_username
            // 
            this.comboBox_username.DataSource = this.registerBindingSource;
            this.comboBox_username.DisplayMember = "User_Name";
            this.comboBox_username.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_username.FormattingEnabled = true;
            this.comboBox_username.Location = new System.Drawing.Point(186, 247);
            this.comboBox_username.Name = "comboBox_username";
            this.comboBox_username.Size = new System.Drawing.Size(200, 29);
            this.comboBox_username.TabIndex = 83;
            this.comboBox_username.ValueMember = "User_Name";
            // 
            // registerBindingSource
            // 
            this.registerBindingSource.DataMember = "Register";
            this.registerBindingSource.DataSource = this.databaseDataSet2;
            // 
            // databaseDataSet2
            // 
            this.databaseDataSet2.DataSetName = "DatabaseDataSet2";
            this.databaseDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label_stuff_user_name
            // 
            this.label_stuff_user_name.AutoSize = true;
            this.label_stuff_user_name.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_stuff_user_name.ForeColor = System.Drawing.Color.DimGray;
            this.label_stuff_user_name.Location = new System.Drawing.Point(38, 252);
            this.label_stuff_user_name.Name = "label_stuff_user_name";
            this.label_stuff_user_name.Size = new System.Drawing.Size(135, 19);
            this.label_stuff_user_name.TabIndex = 77;
            this.label_stuff_user_name.Text = "Stuff User Name :";
            // 
            // label_borrowing_date
            // 
            this.label_borrowing_date.AutoSize = true;
            this.label_borrowing_date.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_borrowing_date.ForeColor = System.Drawing.Color.DimGray;
            this.label_borrowing_date.Location = new System.Drawing.Point(38, 328);
            this.label_borrowing_date.Name = "label_borrowing_date";
            this.label_borrowing_date.Size = new System.Drawing.Size(134, 19);
            this.label_borrowing_date.TabIndex = 75;
            this.label_borrowing_date.Text = "Borrowing Date :";
            // 
            // label_due_date
            // 
            this.label_due_date.AutoSize = true;
            this.label_due_date.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_due_date.ForeColor = System.Drawing.Color.DimGray;
            this.label_due_date.Location = new System.Drawing.Point(39, 402);
            this.label_due_date.Name = "label_due_date";
            this.label_due_date.Size = new System.Drawing.Size(88, 19);
            this.label_due_date.TabIndex = 79;
            this.label_due_date.Text = "Due Date :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1131, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 30);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 72;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // button_add_borrowing
            // 
            this.button_add_borrowing.BackColor = System.Drawing.Color.Tan;
            this.button_add_borrowing.FlatAppearance.BorderSize = 0;
            this.button_add_borrowing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add_borrowing.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_add_borrowing.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_add_borrowing.Location = new System.Drawing.Point(144, 444);
            this.button_add_borrowing.Margin = new System.Windows.Forms.Padding(0);
            this.button_add_borrowing.Name = "button_add_borrowing";
            this.button_add_borrowing.Size = new System.Drawing.Size(149, 35);
            this.button_add_borrowing.TabIndex = 71;
            this.button_add_borrowing.Text = "Add Order";
            this.button_add_borrowing.UseVisualStyleBackColor = false;
            this.button_add_borrowing.Click += new System.EventHandler(this.button_add_borrowing_Click);
            // 
            // button_update_order
            // 
            this.button_update_order.BackColor = System.Drawing.Color.Tan;
            this.button_update_order.FlatAppearance.BorderSize = 0;
            this.button_update_order.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update_order.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update_order.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_update_order.Location = new System.Drawing.Point(858, 443);
            this.button_update_order.Margin = new System.Windows.Forms.Padding(0);
            this.button_update_order.Name = "button_update_order";
            this.button_update_order.Size = new System.Drawing.Size(149, 35);
            this.button_update_order.TabIndex = 69;
            this.button_update_order.Text = "Update Order";
            this.button_update_order.UseVisualStyleBackColor = false;
            this.button_update_order.Click += new System.EventHandler(this.button_update_order_Click);
            // 
            // button_clear_order
            // 
            this.button_clear_order.BackColor = System.Drawing.Color.Tan;
            this.button_clear_order.FlatAppearance.BorderSize = 0;
            this.button_clear_order.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_clear_order.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear_order.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_clear_order.Location = new System.Drawing.Point(692, 444);
            this.button_clear_order.Margin = new System.Windows.Forms.Padding(0);
            this.button_clear_order.Name = "button_clear_order";
            this.button_clear_order.Size = new System.Drawing.Size(149, 35);
            this.button_clear_order.TabIndex = 69;
            this.button_clear_order.Text = "Clear Order";
            this.button_clear_order.UseVisualStyleBackColor = false;
            this.button_clear_order.Click += new System.EventHandler(this.button_clear_order_Click);
            // 
            // button_delete_order
            // 
            this.button_delete_order.BackColor = System.Drawing.Color.Tan;
            this.button_delete_order.FlatAppearance.BorderSize = 0;
            this.button_delete_order.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_delete_order.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete_order.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_delete_order.Location = new System.Drawing.Point(495, 444);
            this.button_delete_order.Margin = new System.Windows.Forms.Padding(0);
            this.button_delete_order.Name = "button_delete_order";
            this.button_delete_order.Size = new System.Drawing.Size(175, 35);
            this.button_delete_order.TabIndex = 70;
            this.button_delete_order.Text = "Return and Delete Order";
            this.button_delete_order.UseVisualStyleBackColor = false;
            this.button_delete_order.Click += new System.EventHandler(this.button_delete_order_Click);
            // 
            // button_return_book
            // 
            this.button_return_book.BackColor = System.Drawing.Color.Tan;
            this.button_return_book.FlatAppearance.BorderSize = 0;
            this.button_return_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_return_book.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_return_book.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button_return_book.Location = new System.Drawing.Point(317, 444);
            this.button_return_book.Margin = new System.Windows.Forms.Padding(0);
            this.button_return_book.Name = "button_return_book";
            this.button_return_book.Size = new System.Drawing.Size(149, 35);
            this.button_return_book.TabIndex = 68;
            this.button_return_book.Text = "Return Book";
            this.button_return_book.UseVisualStyleBackColor = false;
            this.button_return_book.Click += new System.EventHandler(this.button_return_book_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(413, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 19);
            this.label4.TabIndex = 26;
            this.label4.Text = "Search By client Ref :";
            // 
            // lable_title_borrow
            // 
            this.lable_title_borrow.AutoSize = true;
            this.lable_title_borrow.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lable_title_borrow.ForeColor = System.Drawing.Color.DimGray;
            this.lable_title_borrow.Location = new System.Drawing.Point(623, 15);
            this.lable_title_borrow.Name = "lable_title_borrow";
            this.lable_title_borrow.Size = new System.Drawing.Size(329, 32);
            this.lable_title_borrow.TabIndex = 4;
            this.lable_title_borrow.Text = "Borrow or Return a Book";
            // 
            // vScrollBar2
            // 
            this.vScrollBar2.Location = new System.Drawing.Point(1125, 119);
            this.vScrollBar2.Name = "vScrollBar2";
            this.vScrollBar2.Size = new System.Drawing.Size(17, 292);
            this.vScrollBar2.TabIndex = 3;
            // 
            // dataGridView_borrow_book
            // 
            this.dataGridView_borrow_book.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_borrow_book.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dataGridView_borrow_book.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_borrow_book.Location = new System.Drawing.Point(408, 119);
            this.dataGridView_borrow_book.Name = "dataGridView_borrow_book";
            this.dataGridView_borrow_book.RowHeadersWidth = 62;
            this.dataGridView_borrow_book.Size = new System.Drawing.Size(714, 292);
            this.dataGridView_borrow_book.TabIndex = 2;
            this.dataGridView_borrow_book.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_borrow_book_CellContentClick);
            // 
            // panel_control
            // 
            this.panel_control.BackColor = System.Drawing.Color.Tan;
            this.panel_control.Controls.Add(this.button_borrow_book);
            this.panel_control.Controls.Add(this.button_clientshandling);
            this.panel_control.Controls.Add(this.button_books);
            this.panel_control.Controls.Add(this.link_logout);
            this.panel_control.Controls.Add(this.label_sublogo);
            this.panel_control.Controls.Add(this.label_logo);
            this.panel_control.Controls.Add(this.picture_logo);
            this.panel_control.Location = new System.Drawing.Point(11, 9);
            this.panel_control.Margin = new System.Windows.Forms.Padding(0);
            this.panel_control.Name = "panel_control";
            this.panel_control.Size = new System.Drawing.Size(293, 497);
            this.panel_control.TabIndex = 16;
            // 
            // button_borrow_book
            // 
            this.button_borrow_book.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_borrow_book.FlatAppearance.BorderSize = 0;
            this.button_borrow_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_borrow_book.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_borrow_book.ForeColor = System.Drawing.Color.DimGray;
            this.button_borrow_book.Location = new System.Drawing.Point(30, 291);
            this.button_borrow_book.Margin = new System.Windows.Forms.Padding(0);
            this.button_borrow_book.Name = "button_borrow_book";
            this.button_borrow_book.Size = new System.Drawing.Size(229, 35);
            this.button_borrow_book.TabIndex = 15;
            this.button_borrow_book.Text = "Borrow a Book";
            this.button_borrow_book.UseVisualStyleBackColor = false;
            this.button_borrow_book.Click += new System.EventHandler(this.button_stuffcontrol_Click);
            // 
            // button_clientshandling
            // 
            this.button_clientshandling.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_clientshandling.FlatAppearance.BorderSize = 0;
            this.button_clientshandling.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_clientshandling.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clientshandling.ForeColor = System.Drawing.Color.DimGray;
            this.button_clientshandling.Location = new System.Drawing.Point(30, 220);
            this.button_clientshandling.Margin = new System.Windows.Forms.Padding(0);
            this.button_clientshandling.Name = "button_clientshandling";
            this.button_clientshandling.Size = new System.Drawing.Size(229, 35);
            this.button_clientshandling.TabIndex = 15;
            this.button_clientshandling.Text = "Client";
            this.button_clientshandling.UseVisualStyleBackColor = false;
            this.button_clientshandling.Click += new System.EventHandler(this.button_clientshandling_Click);
            // 
            // button_books
            // 
            this.button_books.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_books.FlatAppearance.BorderSize = 0;
            this.button_books.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_books.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_books.ForeColor = System.Drawing.Color.DimGray;
            this.button_books.Location = new System.Drawing.Point(30, 151);
            this.button_books.Margin = new System.Windows.Forms.Padding(0);
            this.button_books.Name = "button_books";
            this.button_books.Size = new System.Drawing.Size(229, 35);
            this.button_books.TabIndex = 14;
            this.button_books.Text = "Book";
            this.button_books.UseVisualStyleBackColor = false;
            this.button_books.Click += new System.EventHandler(this.button_bookmanagement_Click);
            // 
            // link_logout
            // 
            this.link_logout.AutoSize = true;
            this.link_logout.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.link_logout.LinkColor = System.Drawing.Color.Black;
            this.link_logout.Location = new System.Drawing.Point(99, 452);
            this.link_logout.Name = "link_logout";
            this.link_logout.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.link_logout.Size = new System.Drawing.Size(61, 19);
            this.link_logout.TabIndex = 4;
            this.link_logout.TabStop = true;
            this.link_logout.Text = "Logout";
            this.link_logout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_logout_LinkClicked);
            // 
            // label_sublogo
            // 
            this.label_sublogo.AutoSize = true;
            this.label_sublogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_sublogo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sublogo.ForeColor = System.Drawing.Color.White;
            this.label_sublogo.Location = new System.Drawing.Point(54, 384);
            this.label_sublogo.Name = "label_sublogo";
            this.label_sublogo.Size = new System.Drawing.Size(163, 38);
            this.label_sublogo.TabIndex = 2;
            this.label_sublogo.Text = "Library \r\nManagment System";
            this.label_sublogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_logo
            // 
            this.label_logo.AutoSize = true;
            this.label_logo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_logo.ForeColor = System.Drawing.Color.White;
            this.label_logo.Location = new System.Drawing.Point(86, 96);
            this.label_logo.Name = "label_logo";
            this.label_logo.Size = new System.Drawing.Size(101, 16);
            this.label_logo.TabIndex = 1;
            this.label_logo.Text = "Insight Library";
            // 
            // picture_logo
            // 
            this.picture_logo.Image = ((System.Drawing.Image)(resources.GetObject("picture_logo.Image")));
            this.picture_logo.Location = new System.Drawing.Point(103, 24);
            this.picture_logo.Margin = new System.Windows.Forms.Padding(0);
            this.picture_logo.Name = "picture_logo";
            this.picture_logo.Size = new System.Drawing.Size(60, 72);
            this.picture_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture_logo.TabIndex = 0;
            this.picture_logo.TabStop = false;
            // 
            // bookTableAdapter
            // 
            this.bookTableAdapter.ClearBeforeFill = true;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // registerTableAdapter
            // 
            this.registerTableAdapter.ClearBeforeFill = true;
            // 
            // form_work_interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1478, 515);
            this.Controls.Add(this.panel_borrow_book);
            this.Controls.Add(this.panel_book);
            this.Controls.Add(this.panel_client);
            this.Controls.Add(this.panel_control);
            this.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.ForeColor = System.Drawing.Color.Tan;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "form_work_interface";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.form_work_interface_Load);
            this.panel_book.ResumeLayout(false);
            this.panel_book.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_books)).EndInit();
            this.panel_client.ResumeLayout(false);
            this.panel_client.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_client)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_borrow_book.ResumeLayout(false);
            this.panel_borrow_book.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.registerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_borrow_book)).EndInit();
            this.panel_control.ResumeLayout(false);
            this.panel_control.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_book;
        private System.Windows.Forms.PictureBox button_close;
        private System.Windows.Forms.Button button_add_book;
        private System.Windows.Forms.Button button_clear_book;
        private System.Windows.Forms.Button button_delete_book;
        private System.Windows.Forms.Button button_update_book;
        private System.Windows.Forms.ComboBox comboBox_book_shell;
        private System.Windows.Forms.Label label_tytel;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.DataGridView dataGridView_books;
        private System.Windows.Forms.TextBox text_author;
        private System.Windows.Forms.TextBox text_bookname;
        private System.Windows.Forms.Label label_autor;
        private System.Windows.Forms.Label label_availability;
        private System.Windows.Forms.Label label_bookid_number;
        private System.Windows.Forms.Label label_book_shell;
        private System.Windows.Forms.Panel panel_control;
        private System.Windows.Forms.Button button_borrow_book;
        private System.Windows.Forms.Button button_clientshandling;
        private System.Windows.Forms.Button button_books;
        private System.Windows.Forms.LinkLabel link_logout;
        private System.Windows.Forms.Label label_sublogo;
        private System.Windows.Forms.Label label_logo;
        private System.Windows.Forms.PictureBox picture_logo;
        private System.Windows.Forms.Panel panel_client;
        private System.Windows.Forms.Panel panel_borrow_book;
        private System.Windows.Forms.Label label_stuff_user_name;
        private System.Windows.Forms.Label label_borrowing_date;
        private System.Windows.Forms.Label label_due_date;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button_add_borrowing;
        private System.Windows.Forms.Button button_clear_order;
        private System.Windows.Forms.Button button_delete_order;
        private System.Windows.Forms.Button button_return_book;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lable_title_borrow;
        private System.Windows.Forms.VScrollBar vScrollBar2;
        private System.Windows.Forms.DataGridView dataGridView_borrow_book;
        private System.Windows.Forms.TextBox text_phone_number;
        private System.Windows.Forms.TextBox text_fullname_client;
        private System.Windows.Forms.TextBox text_client_ref;
        private System.Windows.Forms.Label label_phone_number;
        private System.Windows.Forms.Label label_fullname_client;
        private System.Windows.Forms.Label label_clientref;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_add_client;
        private System.Windows.Forms.Button button_clear_client;
        private System.Windows.Forms.Button button_delete_client;
        private System.Windows.Forms.Button button_update_client;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.VScrollBar vScrollBar4;
        private System.Windows.Forms.DateTimePicker dateTimePicker_borrowing_date;
        private System.Windows.Forms.Label label_language;
        private System.Windows.Forms.ComboBox comboBox_availability;
        private System.Windows.Forms.Label label_book_gener;
        private System.Windows.Forms.ComboBox comboBox_book_gener;
        private System.Windows.Forms.ComboBox comboBox_book_language;
        private System.Windows.Forms.TextBox text_email_address;
        private System.Windows.Forms.Label label_email_address;
        private System.Windows.Forms.ComboBox comboBox_username;
        private System.Windows.Forms.DataGridView dataGridView_client;
        private System.Windows.Forms.TextBox text_book_ref;
        private System.Windows.Forms.Label label_bookname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_bookref;
        private System.Windows.Forms.ComboBox comboBox_clientref;
        private DatabaseDataSet databaseDataSet;
        private System.Windows.Forms.BindingSource bookBindingSource;
        private DatabaseDataSetTableAdapters.BookTableAdapter bookTableAdapter;
        private DatabaseDataSet1 databaseDataSet1;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private DatabaseDataSet1TableAdapters.ClientTableAdapter clientTableAdapter;
        private DatabaseDataSet2 databaseDataSet2;
        private System.Windows.Forms.BindingSource registerBindingSource;
        private DatabaseDataSet2TableAdapters.RegisterTableAdapter registerTableAdapter;
        private System.Windows.Forms.Button button_update_order;
        private System.Windows.Forms.DateTimePicker dateTimePicker_due_date;
        private System.Windows.Forms.Button button_searchbar_borrow;
        private System.Windows.Forms.TextBox textBox_searchbar_borrow;
        private System.Windows.Forms.Button button_S_B;
        private System.Windows.Forms.TextBox textBox_S_B;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_Search_Book_PanelBook;
        private System.Windows.Forms.TextBox textBox_Search_Book_PanelBook;
        private System.Windows.Forms.Button button_Search_client_panelclient;
        private System.Windows.Forms.TextBox textBox_Search_client_panelclient;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_Search_Bookname_PanelBook;
        private System.Windows.Forms.TextBox textBox_Search_Bookname_PanelBook;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button_Search_clientname_panelclient;
        private System.Windows.Forms.TextBox textBox_Search_clientname_panelclient;
        private System.Windows.Forms.Button button_S_B_S;
        private System.Windows.Forms.TextBox textBox_S_B_S;
        private System.Windows.Forms.Label label10;
    }
}